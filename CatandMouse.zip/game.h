#ifndef GAME_H
#define GAME_H

#include "configuration.h"
#include "race.h"

class Game
{
    Configuration Config;
    Race race;
    Track *track;
    vector<Car*> Player;
    sf::Texture CarTexture;
    sf::Texture TrackTexture;
    sf::RenderWindow *Window;
    sf::VertexArray TrackTiles;
    double Scaling;
    unsigned padding;
    bool paddingdim;
    unsigned RenderSize=32;
    sf::Clock Clock;
    void PrepareandScaleTriangle(sf::Vertex *quad, Vector2i TextPos, Vector2i Pos, unsigned Orientation);


public:
    Game();

    bool GameActive;
    void init(Configuration &NewConfig, sf::RenderWindow &NewWindow);
    void ProcessEvents(sf::Event &Event);
    void Update(double DeltaTime);
    double getTime();
    void Render();
};




#endif // GAME_H
