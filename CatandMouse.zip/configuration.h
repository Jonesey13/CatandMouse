#ifndef CONFIGURATION_H
#define CONFIGURATION_H


#include <SFML/System.hpp>
#include <SFML/Window.hpp>
#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include <vector>

using namespace std;
using Vector2d=sf::Vector2<double>;
using Vector2u=sf::Vector2u;
using Vector2i=sf::Vector2i;
using Vector2f=sf::Vector2f;

class Configuration
{
public:
    // Global Settings
    unsigned NumberOfPlayers=2;
    vector<unsigned> JoyId={0,0,0,0,0,0,0,0};
    unsigned TrackNumber=1;

    //Editor Options
    Vector2u NewTrackDim=Vector2u(20,20);
    bool BlankTrack=0;
};



#endif // CONFIGURATION_H
