#ifndef MENUITEM_H
#define MENUITEM_H

#include <SFML/System.hpp>
#include <SFML/Window.hpp>
#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>

#include <string>

using namespace std;
using Vector2d=sf::Vector2<double>;
using Vector2u=sf::Vector2u;
using Vector2i=sf::Vector2i;
using Vector2f=sf::Vector2f;



//class MenuItem : public sf::Text
//{
//public:
//    unsigned SelectionIndex;
//    unsigned flag=0;
//};

class MenuItem{
public:
    MenuItem(string Text1, string Text2);
    MenuItem(string Text, unsigned &Target);
    MenuItem(string Text);
    string Item;
    string FlagMessage;
    bool HasFlag=0;
    bool Flag=0;
    bool HasNumber=0;
    unsigned *NumberPointer=nullptr;
};




#endif // MENUITEM_H
