#include "game.h"

Game::Game(){
    GameActive=0;
}

double Game::getTime(){
    return Clock.getElapsedTime().asSeconds();
}

void Game::init(Configuration &NewConfig, sf::RenderWindow &NewWindow){
    GameActive=1;
    CarTexture.loadFromFile("CarSprites.png");
    TrackTexture.loadFromFile("TrackSprites.png");
    Config=NewConfig;
    Window=&NewWindow;
    race.init(Config);

    track=&race.track;

    Player.resize(race.Player.size());
    for (unsigned i=0; i<race.Player.size();i++)
    {
        Player[i]=&race.Player[i];
    }



    Vector2u Resolution=Window->getSize();
    TrackTiles.setPrimitiveType(sf::Triangles);
    Vector2u TrackDim=track->getDim();
    Vector2d TrackRes=Vector2d(RenderSize*TrackDim.x,RenderSize*TrackDim.y);
    Scaling=min(Resolution.x/TrackRes.x, Resolution.y/TrackRes.y);
    if ((Resolution.x/TrackRes.x)>(Resolution.y/TrackRes.y))
    {
        paddingdim=0;
        padding=(Resolution.x-Scaling*TrackRes.x)*0.5;
    }
    else{
        paddingdim=1;
        padding=(Resolution.y-Scaling*TrackRes.y)*0.5;
    }

    Clock.restart();

}


void Game::ProcessEvents(sf::Event &Event){
    while (Window->pollEvent(Event))
    {
        switch (Event.type)
        {
        case sf::Event::Closed:
            {
            Window->close();
            break;
            }
        // Keyboard Input (1 Player Only)
        case sf::Event::KeyPressed:
            switch (Event.key.code)
            {
            case sf::Keyboard::Escape:
                {
                Window->close();
                break;
                }
            case sf::Keyboard::W:
                Player[0]->VelocitySwitch=1;
                break;
            case sf::Keyboard::S:
                Player[0]->BrakeSwitch=1;
                break;
            case sf::Keyboard::A:
                Player[0]->RMinusSwitch=1;
                break;
            case sf::Keyboard::D:
                Player[0]->RPlusSwitch=1;
                break;
            default:
                break;
            }
            break;
        case sf::Event::KeyReleased:
            {
            switch (Event.key.code)
            {
            case sf::Keyboard::W:
                Player[0]->VelocitySwitch=0;
                break;
            case sf::Keyboard::S:
                Player[0]->BrakeSwitch=0;
                break;
            case sf::Keyboard::A:
                Player[0]->RMinusSwitch=0;
                break;
            case sf::Keyboard::D:
                Player[0]->RPlusSwitch=0;
                break;
            default:
                break;
            }
            break;
            }
        default:
            break;
        }
    }
}

void Game::Update(double DeltaTime){
    race.Update(DeltaTime);
}

void Game::Render(){
    Vector2u TrackDim=track->getDim();
    TrackTiles.resize((TrackDim.x*TrackDim.y)*6);
    unsigned current=0;
    for (unsigned i=0; i<TrackDim.x;++i)
    {
        for (unsigned j=0; j< TrackDim.y;++j)
        {
            Vector2i Pos=Vector2i(i,j);
            sf::Vertex *tri= &TrackTiles[current * 3];
            Vector2i TextPos=Vector2i(0,track->getTile(i,j)->Types.x);
            PrepareandScaleTriangle(tri,TextPos,Pos,track->getTile(i,j)->Orientation);
            current++;
            tri = &TrackTiles[current * 3];
            TextPos=Vector2i(0,track->getTile(i,j)->Types.y);
            PrepareandScaleTriangle(tri,TextPos,Pos,track->getTile(i,j)->Orientation+2);
            current++;
        }
    }
    Window->draw(TrackTiles,&TrackTexture);

    sf::Sprite PlayerSprite;
    PlayerSprite.setTexture(CarTexture);
    PlayerSprite.setOrigin(RenderSize/2,RenderSize/2);
    for (unsigned i=0; i<Player.size() ; i++)
    {
        Vector2d PlayerPosition=static_cast<double>(RenderSize)*Player[i]->Position;
        PlayerPosition=ScalePosition(PlayerPosition, Scaling, paddingdim, padding);
        PlayerSprite.setPosition(Double2Float(PlayerPosition));
        PlayerSprite.setScale(Scaling,Scaling);
        PlayerSprite.setTextureRect(sf::IntRect(i*RenderSize, 0, RenderSize, RenderSize));
        PlayerSprite.setRotation(360*Player[i]->Rotation);
        Window->draw(PlayerSprite);
    }
    Window->display();
    Window->clear();
}

void Game::PrepareandScaleTriangle(sf::Vertex *tri, Vector2i TextPos, Vector2i Pos, unsigned Orientation){
    vector<sf::Vertex> quad(4);
    quad[0].position=Double2Float(Vector2d(Pos.x*RenderSize, Pos.y*RenderSize));
    quad[1].position=Double2Float(Vector2d(Pos.x*RenderSize, (Pos.y+1)*RenderSize));
    quad[2].position=Double2Float(Vector2d((Pos.x+1)*RenderSize, (Pos.y+1)*RenderSize));
    quad[3].position=Double2Float(Vector2d((Pos.x+1)*RenderSize, Pos.y*RenderSize));
    for (unsigned i=0; i<4;i++)
    {
        quad[i].position=ScalePosition(quad[i].position,Scaling,paddingdim,padding);
    }


    quad[0].texCoords=Vector2f(TextPos.x*RenderSize, TextPos.y*RenderSize);
    quad[1].texCoords=Vector2f(TextPos.x*RenderSize, (TextPos.y+1)*RenderSize);
    quad[2].texCoords=Vector2f((TextPos.x+1)*RenderSize, (TextPos.y+1)*RenderSize);
    quad[3].texCoords=Vector2f((TextPos.x+1)*RenderSize, TextPos.y*RenderSize);

    for (unsigned i=0; i<3; i++)
    {
        tri[i]=quad[(i+Orientation)%4];
    }

}
