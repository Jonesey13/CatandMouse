#ifndef TRACK_H
#define TRACK_H


#include <iostream>
#include <fstream>
#include <sstream>

#include "tile.h"



class Track
{
    vector<vector<Tile>> Tiles;
    Vector2u Dim;
    enum PROPERTIES {FALL, NORMTRACTION, SLIDING, FINISH, WALL};

public:
    Track();
    void init(unsigned TrackNumber);
    vector<Vector2u> StartingPositions;
    Vector2u getDim();
    Tile *getTile(unsigned i, unsigned j);
    bool TrackReady=0;
    unsigned FinishDirection=0;
    unsigned TotalStarting=4;

    void SetBlank(sf::Vector2u NewDim);
    void ReadTrack(unsigned TrackNumber);
    void WriteTrack(unsigned TrackNumber);
    void FlushTrack(unsigned TrackNumber);
    void RefreshDetection();
};





#endif // TRACK_H




