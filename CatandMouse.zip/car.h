#ifndef CAR_H
#define CAR_H

#include "functions.h"




class Car
{
public:
    Car();

    double DrivingForce;
    double Braking;
    double Reversing;
    Vector2d Velocity;
    double Rotation;
    Vector2d Position;
    double TurningRate;
    bool VelocitySwitch;
    bool BrakeSwitch;
    bool RPlusSwitch;
    bool RMinusSwitch;

    void Update(double DeltaTime);
};

#endif // CAR_H
