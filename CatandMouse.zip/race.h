#ifndef RACE_H
#define RACE_H

#include "car.h"
#include "track.h"
#include "configuration.h"

class Race
{
public:
    Configuration Config;
    Track track;
    vector<Car> Player;
    Race();

    void init(Configuration &NewConfig);
    void Update(double DeltaTime);
};










#endif // RACE_H
