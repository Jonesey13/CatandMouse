#ifndef EDITOR_H
#define EDITOR_H

#include "configuration.h"
#include "track.h"
#include "clickable.h"
#include "functions.h"


#include <iostream>
#include <sstream>



class Editor
{
    sf::Font font;
    sf::Texture ButtonTexture;
    sf::Texture TrackTexture;
    Configuration Config;
    Track track;
    sf::RenderWindow *Window;
    sf::Clock Clock;
    sf::VertexArray TrackTiles;
    sf::VertexArray OverLay;
    vector<Clickable<bool>> ClickableBools;
    vector<Clickable<unsigned>> ClickableUnsigneds;
    Clickable<unsigned> ClickableSelection;
    unsigned RenderSize=32;
    bool OverLayON;
    double Scaling;
    double ScalingTrack;
    double ScalingTools;
    bool ClickLeft;
    bool ClickRight;
    bool PreExitFlag;
    bool ExitFlag;
    bool StartFlag;
    bool SaveFlag;
    unsigned PaintSelection;
    unsigned PlayerSelection;
    sf::Text ExitMessage;
    void PrepareandScaleTriangle(sf::Vertex *tri, sf::Vertex *lines, Vector2u TextPos,
                                 Vector2u Pos, unsigned Orientation, bool isSquare=0);
    Vector2u getCurrentSquare();
    bool getTriangleHalf(Vector2u Position, bool Orientation);
    vector<sf::Text> StartingNumbers;
    vector<sf::CircleShape> StartingCircles;
    sf::VertexArray ToolBoxes;

public:
    Editor();
    bool EditorActive;
    double getTime();
    void init(Configuration &NewConfig, sf::RenderWindow &NewWindow);
    void ProcessEvents(sf::Event &Event);
    void Update(double DeltaTime);
    void Render();
};




#endif // EDITOR_H
