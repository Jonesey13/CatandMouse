#ifndef FUNCTIONS_H
#define FUNCTIONS_H

#include <SFML/System.hpp>
#include <SFML/Window.hpp>
#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include <vector>
#include <math.h>
#define M_PI 3.14159265358979323846

using namespace std;
using Vector2d=sf::Vector2<double>;
using Vector2u=sf::Vector2u;
using Vector2i=sf::Vector2i;
using Vector2f=sf::Vector2f;


Vector2d RotateVector(Vector2d input, double rotation);
double DotProduct(Vector2d vector1, Vector2d vector2);
Vector2f Double2Float(Vector2d input);
Vector2d ScalePosition(Vector2d position, double Scaling, bool paddingdim, unsigned padding);
Vector2f ScalePosition(Vector2f position, double Scaling, bool paddingdim, unsigned padding);



#endif //FUNCTIONS_H
