#include "race.h"

Race::Race(){
}


void Race::init(Configuration &NewConfig){
    Config=NewConfig;
    track.ReadTrack(Config.TrackNumber);
    Car car;
    for(unsigned i=0; i< Config.NumberOfPlayers; i++){
        Player.push_back(car);
        Player[i].Position=Vector2d(track.StartingPositions[i].x,track.StartingPositions[i].y) +Vector2d(0.5,0.5);
    }
}


void Race::Update(double DeltaTime){
    for (unsigned i=0; i<Player.size() ; i++)
    {
        Player[i].Update(DeltaTime);
    }
}
