The trackeditor lacks any button explantion atm:


MouseLeft: Change Tile Sprite to Number Chosen
MouseRight: Switch Tile state from Square->Triangle1->Triangle2->Square
num 1-5: Change Painting Sprite
S: Set Starting Position for Car1
Enter: Exit Editor with Save Options

Resizing the window will break mouse functionality!