#include "menuitem.h"

MenuItem::MenuItem(string Text1, string Text2, void Selection()){
    Item=Text1;
    FlagMessage=Text2;
    HasFlag=1;
    SelectionFunction=Selection;
}

MenuItem::MenuItem(string Text, unsigned &Target, void Selection()){
    Item=Text;
    NumberPointer=&Target;
    SelectionFunction=Selection;
}

MenuItem::MenuItem(string Text, void Selection()){
    Item=Text;
    SelectionFunction=Selection;
}
